# Melissa Acosta · Organizational Development Portfolio

A static GitHub Pages portfolio focused on Organizational Development, Talent Planning, Succession, People Analytics, Role Architecture, Employee Listening, and Leadership Enablement.

## How to publish on GitHub Pages

1. Create a new GitHub repository, for example: `melissa-od-portfolio`.
2. Upload `index.html` to the root of the repository.
3. Go to **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Choose branch: `main`, folder: `/root`.
6. Save.
7. Your site should publish at: `https://YOUR-USERNAME.github.io/melissa-od-portfolio/`.

## What to customize

- Replace the LinkedIn URL if needed.
- Add a resume link if you upload a PDF.
- Add project images/screenshots only after removing confidential information.
- Keep the page focused on OD, succession, analytics, and leadership development rather than talent acquisition.
